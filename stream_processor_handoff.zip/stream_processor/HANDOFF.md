# Person B -> Person C

> Fill in every `[ ]` below by actually running the steps yourself before
> opening your PR. An unchecked box means "not verified yet" — don't hand
> off on a guess.

## What I built

A Kafka consumer (`consumer.py`) that reads every event Person A's
producer sends, checks its `type`, and routes it into the database
that's the right fit for that kind of data:

| Topic      | Routed to                         | Why |
|------------|------------------------------------|-----|
| `orders`   | MongoDB (`shopsphere.orders`)      | Order documents are semi-structured — Mongo doesn't force a rigid shape |
| `orders`   | Neo4j (`User -[:BOUGHT]-> Product`)| Every order already carries a user + product, so it doubles as relationship data |
| `clicks`   | Cassandra (`shopsphere.clicks`)    | High-volume, always read back in time order |
| `sessions` | Redis (`active_users` set)         | Needs to answer "who's online right now" instantly |

Also included, **optional but recommended**:
- `db_writers/redis_writer.py: update_order_metrics()` — pre-aggregates
  `orders:count`, `orders:revenue_today`, and `orders:recent` in Redis on
  every order, so your `/api/revenue`, `/api/orders`, and live-feed
  endpoints can read one instant value instead of scanning MongoDB.
- `seed_products.py` — a small `products` collection (`product_id -> name`)
  in MongoDB, since Person A's events only carry raw product IDs like
  `P23`, and the final dashboard is expected to show real product names.

## How to run

1. From the repo root: `docker compose up -d` (starts Kafka, Zookeeper, MongoDB, Cassandra, Redis, Neo4j)
2. Wait ~30-60s for Cassandra specifically — it's slow to accept connections after startup
3. `cd stream_processor && pip install -r requirements.txt`
4. `python seed_products.py` (optional, one-time)
5. In one terminal: `cd ../producer && python kafka_producer.py`
6. In another terminal: `cd stream_processor && python consumer.py`

## Expected result

You should see lines like:
```
[orders]   -> MongoDB + Neo4j   | ORD4821 ($199.0)
[clicks]   -> Cassandra         | USR233 viewed product_detail
[sessions] -> Redis             | USR118 is active
```

Verify each database directly:
- **MongoDB:** `mongosh` -> `use shopsphere` -> `db.orders.find().limit(5)`
- **Cassandra:** `docker exec -it cassandra cqlsh` -> `SELECT * FROM shopsphere.clicks LIMIT 5;`
- **Redis:** `docker exec -it redis redis-cli` -> `SMEMBERS active_users` and `GET orders:count`
- **Neo4j:** open `http://localhost:7474` (login neo4j/password) -> `MATCH (u)-[b:BOUGHT]->(p) RETURN u,b,p LIMIT 25`

- [ ] Confirmed real order documents appear in MongoDB
- [ ] Confirmed real click rows appear in Cassandra
- [ ] Confirmed `active_users` set updates as sessions arrive
- [ ] Confirmed `User -[:BOUGHT]-> Product` relationships appear in Neo4j
- [ ] Confirmed `orders:count` / `orders:revenue_today` / `orders:recent` increment correctly

## Sample queries C can build the API around

```python
# Mongo — recent orders
db.orders.find().sort("timestamp", -1).limit(20)

# Redis — instant dashboard numbers
r.get("orders:count")
r.get("orders:revenue_today")
r.scard("active_users")
r.lrange("orders:recent", 0, 19)

# Neo4j — "customers who bought X also bought Y"
MATCH (p:Product {id: $product_id})<-[:BOUGHT]-(u:User)-[:BOUGHT]->(rec:Product)
WHERE rec.id <> $product_id
RETURN rec.id, count(*) AS times_bought_together
ORDER BY times_bought_together DESC LIMIT 5
```

## Important notes

- The `type` field on every event determines routing — don't rename it upstream.
- `docker-compose.yml` moved from `producer/` to the repo root, and now
  includes all 4 databases alongside Kafka/Zookeeper, so the whole stack
  starts with one `docker compose up -d` from the root. Flag this to
  Person A/the team since it touches a file they created.
- `products` collection is seeded with a partial ID->name list (P10-P19).
  Any product_id outside that range won't have a friendly name yet —
  a deliberate, disclosed scope decision, not a bug.

## Known issues / limitations

- [ ] _(fill in after testing — e.g. "Cassandra write occasionally times out on first event after startup, retrying works")_
